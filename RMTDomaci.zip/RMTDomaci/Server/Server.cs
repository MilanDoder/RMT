﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public class Server
    {
        private Socket serverSoket;

        public void PokreniServer() {

            try
            {
                serverSoket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                serverSoket.Bind(new IPEndPoint(IPAddress.Any,10000));
                serverSoket.Listen(5);


                while (true) {
                    Console.WriteLine("Cekamo klijenta!");
                    Socket klijentSoket = serverSoket.Accept();
                    Console.WriteLine("Klijent prihvacen!");

                    ObradaKlijenta obrada = new ObradaKlijenta(serverSoket);
                    obrada.Obrada();
                }
            }
            catch (Exception)
            {

                Console.WriteLine("Server je vec pokrenut!");
            }

        }
    }
}
