﻿using Klase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Server
{
    public class ObradaKlijenta
    {

        private Socket socket;
        private NetworkStream stream;
        private BinaryFormatter formater;

        public ObradaKlijenta(Socket socket)
        {
            this.socket = socket;
            this.stream = new NetworkStream(socket);
            this.formater = new BinaryFormatter();
        }


        public void Obrada() {
            try
            {
                bool kraj = false;

                while (!kraj) {

                    ZahtevKlijenta zahtev = (ZahtevKlijenta)formater.Deserialize(this.stream);
                    OdgovorServera odgovor = new OdgovorServera();

                    switch (zahtev.Operacija) {

                        case Operacija.Prijava:
                            odgovor.Uspesnost = true; break;
                        case Operacija.Registracija:
                            odgovor.Uspesnost = true; break;
                        case Operacija.Izracunaj: odgovor.Podaci = izracunajIzraz(zahtev.Podaci.ToString()).ToString();
                            odgovor.Uspesnost = true; break;
                        default: kraj = true;break;

                    }
                    
                    formater.Serialize(stream,odgovor);
                    
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                
            }
            finally {
                socket.Shutdown(SocketShutdown.Both);
                socket.Close();
            }

        }

        private int izracunajIzraz(string izraz)
        {
            int sum = int.MinValue;
            if (izraz.Contains("+"))
            {
                string prvibroj = izraz.Substring(0, izraz.IndexOf("+"));
                string drugibroj = izraz.Substring(izraz.IndexOf("+") + 1);
                sum = Convert.ToInt32(prvibroj) + Convert.ToInt32(drugibroj);
            }
            else if (izraz.Contains("-"))
            {
               
                string prvibroj = izraz.Substring(0, izraz.IndexOf("-"));
                string drugibroj = izraz.Substring(izraz.IndexOf("-") + 1);

                sum = Convert.ToInt32(prvibroj) - Convert.ToInt32(drugibroj);

            }
            else if (izraz.Contains("*"))
            {
               
                string prvibroj = izraz.Substring(0, izraz.IndexOf("*"));
                string drugibroj = izraz.Substring(izraz.IndexOf("*") + 1);
                sum = Convert.ToInt32(prvibroj) * Convert.ToInt32(drugibroj);
            }
            else if (izraz.Contains("/")) {
                string prvibroj = izraz.Substring(0, izraz.IndexOf("/"));
                string drugibroj = izraz.Substring(izraz.IndexOf("/") + 1);
                sum = Convert.ToInt32(prvibroj) / Convert.ToInt32(drugibroj);
            }



                return sum;
        }

        

        
    }
}
