﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Klase
{
    public class Korisnik
    {
        /// <summary>
        /// Promenljive koje ima klasa Korisnik
        /// i njihove get i set metode
        /// </summary>
        public string KorisnickoIme { get; set; }
        public string KorisnickaSifra { get; set; }
        public string Ime { get; set; }
        public string Prezime { get; set; }

        public override string ToString()
        {
            return $"{Ime} {Prezime}";
        }
    }
}
