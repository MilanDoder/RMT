﻿using Klase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Forme
{
    public class Klijent
    {
        private static Klijent _instanca;
        private TcpClient klijent;
        private NetworkStream stream;
        private BinaryFormatter formater;


        public static Klijent Instanca
        {
            get
            {
                if (_instanca == null)
                {
                    _instanca = new Klijent();
                }
                return _instanca;
            }
        }

        private Klijent()
        {
            klijent = new TcpClient("127.0.0.1", 10000);
            stream = this.klijent.GetStream();
            formater = new BinaryFormatter();
        }

        public string izracunaj(string izraz) {
            ZahtevKlijenta zahtev = new ZahtevKlijenta
            {
                Operacija =  Operacija.Izracunaj,
                Podaci = izraz
            };

            formater.Serialize(stream, zahtev);

            OdgovorServera odgovor = (OdgovorServera)formater.Deserialize(this.stream);

            if (odgovor.Uspesnost)
            {
                return (string)odgovor.Podaci;
            }
            else {
                throw new Exception(odgovor.Podaci.ToString());
            }

        }



    }
}
