﻿namespace Forme
{
    partial class Kalkulator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_zbir = new System.Windows.Forms.Button();
            this.btn_razlika = new System.Windows.Forms.Button();
            this.btn_puta = new System.Windows.Forms.Button();
            this.btn_podeljeno = new System.Windows.Forms.Button();
            this.btn_nula = new System.Windows.Forms.Button();
            this.btn_devet = new System.Windows.Forms.Button();
            this.btn_osam = new System.Windows.Forms.Button();
            this.btn_sedam = new System.Windows.Forms.Button();
            this.btn_sest = new System.Windows.Forms.Button();
            this.btn_pet = new System.Windows.Forms.Button();
            this.btn_cetiri = new System.Windows.Forms.Button();
            this.btn_jednako = new System.Windows.Forms.Button();
            this.btn_tri = new System.Windows.Forms.Button();
            this.btn_dva = new System.Windows.Forms.Button();
            this.btn_jedan = new System.Windows.Forms.Button();
            this.lbl_korisnikPodaci = new System.Windows.Forms.Label();
            this.rtxt_rezultat = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_zbir);
            this.groupBox1.Controls.Add(this.btn_razlika);
            this.groupBox1.Controls.Add(this.btn_puta);
            this.groupBox1.Controls.Add(this.btn_podeljeno);
            this.groupBox1.Controls.Add(this.btn_nula);
            this.groupBox1.Controls.Add(this.btn_devet);
            this.groupBox1.Controls.Add(this.btn_osam);
            this.groupBox1.Controls.Add(this.btn_sedam);
            this.groupBox1.Controls.Add(this.btn_sest);
            this.groupBox1.Controls.Add(this.btn_pet);
            this.groupBox1.Controls.Add(this.btn_cetiri);
            this.groupBox1.Controls.Add(this.btn_jednako);
            this.groupBox1.Controls.Add(this.btn_tri);
            this.groupBox1.Controls.Add(this.btn_dva);
            this.groupBox1.Controls.Add(this.btn_jedan);
            this.groupBox1.Location = new System.Drawing.Point(12, 94);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(158, 171);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // btn_zbir
            // 
            this.btn_zbir.Location = new System.Drawing.Point(115, 22);
            this.btn_zbir.Name = "btn_zbir";
            this.btn_zbir.Size = new System.Drawing.Size(30, 30);
            this.btn_zbir.TabIndex = 15;
            this.btn_zbir.Text = "+";
            this.btn_zbir.UseVisualStyleBackColor = true;
            this.btn_zbir.Click += new System.EventHandler(this.btn_zbir_Click);
            // 
            // btn_razlika
            // 
            this.btn_razlika.Location = new System.Drawing.Point(79, 22);
            this.btn_razlika.Name = "btn_razlika";
            this.btn_razlika.Size = new System.Drawing.Size(30, 30);
            this.btn_razlika.TabIndex = 14;
            this.btn_razlika.Text = "-";
            this.btn_razlika.UseVisualStyleBackColor = true;
            this.btn_razlika.Click += new System.EventHandler(this.btn_razlika_Click);
            // 
            // btn_puta
            // 
            this.btn_puta.Location = new System.Drawing.Point(43, 22);
            this.btn_puta.Name = "btn_puta";
            this.btn_puta.Size = new System.Drawing.Size(30, 30);
            this.btn_puta.TabIndex = 13;
            this.btn_puta.Text = "*";
            this.btn_puta.UseVisualStyleBackColor = true;
            this.btn_puta.Click += new System.EventHandler(this.btn_puta_Click);
            // 
            // btn_podeljeno
            // 
            this.btn_podeljeno.Location = new System.Drawing.Point(7, 22);
            this.btn_podeljeno.Name = "btn_podeljeno";
            this.btn_podeljeno.Size = new System.Drawing.Size(30, 30);
            this.btn_podeljeno.TabIndex = 12;
            this.btn_podeljeno.Text = "/";
            this.btn_podeljeno.UseVisualStyleBackColor = true;
            this.btn_podeljeno.Click += new System.EventHandler(this.btn_podeljeno_Click);
            // 
            // btn_nula
            // 
            this.btn_nula.Location = new System.Drawing.Point(115, 58);
            this.btn_nula.Name = "btn_nula";
            this.btn_nula.Size = new System.Drawing.Size(30, 30);
            this.btn_nula.TabIndex = 11;
            this.btn_nula.Text = "0";
            this.btn_nula.UseVisualStyleBackColor = true;
            this.btn_nula.Click += new System.EventHandler(this.btn_nula_Click);
            // 
            // btn_devet
            // 
            this.btn_devet.Location = new System.Drawing.Point(79, 58);
            this.btn_devet.Name = "btn_devet";
            this.btn_devet.Size = new System.Drawing.Size(30, 30);
            this.btn_devet.TabIndex = 10;
            this.btn_devet.Text = "9";
            this.btn_devet.UseVisualStyleBackColor = true;
            this.btn_devet.Click += new System.EventHandler(this.btn_devet_Click);
            // 
            // btn_osam
            // 
            this.btn_osam.Location = new System.Drawing.Point(43, 58);
            this.btn_osam.Name = "btn_osam";
            this.btn_osam.Size = new System.Drawing.Size(30, 30);
            this.btn_osam.TabIndex = 9;
            this.btn_osam.Text = "8";
            this.btn_osam.UseVisualStyleBackColor = true;
            this.btn_osam.Click += new System.EventHandler(this.btn_osam_Click);
            // 
            // btn_sedam
            // 
            this.btn_sedam.Location = new System.Drawing.Point(7, 58);
            this.btn_sedam.Name = "btn_sedam";
            this.btn_sedam.Size = new System.Drawing.Size(30, 30);
            this.btn_sedam.TabIndex = 8;
            this.btn_sedam.Text = "7";
            this.btn_sedam.UseVisualStyleBackColor = true;
            this.btn_sedam.Click += new System.EventHandler(this.btn_sedam_Click);
            // 
            // btn_sest
            // 
            this.btn_sest.Location = new System.Drawing.Point(79, 94);
            this.btn_sest.Name = "btn_sest";
            this.btn_sest.Size = new System.Drawing.Size(30, 30);
            this.btn_sest.TabIndex = 6;
            this.btn_sest.Text = "6";
            this.btn_sest.UseVisualStyleBackColor = true;
            this.btn_sest.Click += new System.EventHandler(this.btn_sest_Click);
            // 
            // btn_pet
            // 
            this.btn_pet.Location = new System.Drawing.Point(43, 94);
            this.btn_pet.Name = "btn_pet";
            this.btn_pet.Size = new System.Drawing.Size(30, 30);
            this.btn_pet.TabIndex = 5;
            this.btn_pet.Text = "5";
            this.btn_pet.UseVisualStyleBackColor = true;
            this.btn_pet.Click += new System.EventHandler(this.btn_pet_Click);
            // 
            // btn_cetiri
            // 
            this.btn_cetiri.Location = new System.Drawing.Point(7, 94);
            this.btn_cetiri.Name = "btn_cetiri";
            this.btn_cetiri.Size = new System.Drawing.Size(30, 30);
            this.btn_cetiri.TabIndex = 4;
            this.btn_cetiri.Text = "4";
            this.btn_cetiri.UseVisualStyleBackColor = true;
            this.btn_cetiri.Click += new System.EventHandler(this.btn_cetiri_Click);
            // 
            // btn_jednako
            // 
            this.btn_jednako.Location = new System.Drawing.Point(115, 94);
            this.btn_jednako.Name = "btn_jednako";
            this.btn_jednako.Size = new System.Drawing.Size(30, 66);
            this.btn_jednako.TabIndex = 3;
            this.btn_jednako.Text = "=";
            this.btn_jednako.UseVisualStyleBackColor = true;
            this.btn_jednako.Click += new System.EventHandler(this.btn_jednako_Click);
            // 
            // btn_tri
            // 
            this.btn_tri.Location = new System.Drawing.Point(79, 130);
            this.btn_tri.Name = "btn_tri";
            this.btn_tri.Size = new System.Drawing.Size(30, 30);
            this.btn_tri.TabIndex = 2;
            this.btn_tri.Text = "3";
            this.btn_tri.UseVisualStyleBackColor = true;
            this.btn_tri.Click += new System.EventHandler(this.btn_tri_Click);
            // 
            // btn_dva
            // 
            this.btn_dva.Location = new System.Drawing.Point(43, 130);
            this.btn_dva.Name = "btn_dva";
            this.btn_dva.Size = new System.Drawing.Size(30, 30);
            this.btn_dva.TabIndex = 1;
            this.btn_dva.Text = "2";
            this.btn_dva.UseVisualStyleBackColor = true;
            this.btn_dva.Click += new System.EventHandler(this.btn_dva_Click);
            // 
            // btn_jedan
            // 
            this.btn_jedan.Location = new System.Drawing.Point(7, 130);
            this.btn_jedan.Name = "btn_jedan";
            this.btn_jedan.Size = new System.Drawing.Size(30, 30);
            this.btn_jedan.TabIndex = 0;
            this.btn_jedan.Text = "1";
            this.btn_jedan.UseVisualStyleBackColor = true;
            this.btn_jedan.Click += new System.EventHandler(this.btn_jedan_Click);
            // 
            // lbl_korisnikPodaci
            // 
            this.lbl_korisnikPodaci.AutoSize = true;
            this.lbl_korisnikPodaci.Location = new System.Drawing.Point(14, 12);
            this.lbl_korisnikPodaci.Name = "lbl_korisnikPodaci";
            this.lbl_korisnikPodaci.Size = new System.Drawing.Size(35, 13);
            this.lbl_korisnikPodaci.TabIndex = 2;
            this.lbl_korisnikPodaci.Text = "label1";
            // 
            // rtxt_rezultat
            // 
            this.rtxt_rezultat.Location = new System.Drawing.Point(12, 43);
            this.rtxt_rezultat.Name = "rtxt_rezultat";
            this.rtxt_rezultat.ReadOnly = true;
            this.rtxt_rezultat.Size = new System.Drawing.Size(157, 45);
            this.rtxt_rezultat.TabIndex = 1;
            this.rtxt_rezultat.Text = "";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(127, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(62, 20);
            this.button1.TabIndex = 3;
            this.button1.Text = "Odjava";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Kalkulator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(190, 277);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbl_korisnikPodaci);
            this.Controls.Add(this.rtxt_rezultat);
            this.Controls.Add(this.groupBox1);
            this.Name = "Kalkulator";
            this.Text = "Kalkulator";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_zbir;
        private System.Windows.Forms.Button btn_razlika;
        private System.Windows.Forms.Button btn_puta;
        private System.Windows.Forms.Button btn_podeljeno;
        private System.Windows.Forms.Button btn_nula;
        private System.Windows.Forms.Button btn_devet;
        private System.Windows.Forms.Button btn_osam;
        private System.Windows.Forms.Button btn_sedam;
        private System.Windows.Forms.Button btn_sest;
        private System.Windows.Forms.Button btn_pet;
        private System.Windows.Forms.Button btn_cetiri;
        private System.Windows.Forms.Button btn_jednako;
        private System.Windows.Forms.Button btn_tri;
        private System.Windows.Forms.Button btn_dva;
        private System.Windows.Forms.Button btn_jedan;
        private System.Windows.Forms.RichTextBox rtxt_rezultat;
        private System.Windows.Forms.Label lbl_korisnikPodaci;
        private System.Windows.Forms.Button button1;
    }
}