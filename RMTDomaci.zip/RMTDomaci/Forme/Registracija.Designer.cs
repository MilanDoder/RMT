﻿namespace Forme
{
    partial class Registracija
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_imeKorisnika = new System.Windows.Forms.TextBox();
            this.txt_prezimeKorisnika = new System.Windows.Forms.TextBox();
            this.txt_korisnickoIme = new System.Windows.Forms.TextBox();
            this.txt_sifra = new System.Windows.Forms.TextBox();
            this.txt_sifraPonovo = new System.Windows.Forms.TextBox();
            this.btn_registracija = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ime :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Prezime :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Korisnicko ime :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Sifra :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 134);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Sifra ponovo :";
            // 
            // txt_imeKorisnika
            // 
            this.txt_imeKorisnika.Location = new System.Drawing.Point(100, 21);
            this.txt_imeKorisnika.Name = "txt_imeKorisnika";
            this.txt_imeKorisnika.Size = new System.Drawing.Size(128, 20);
            this.txt_imeKorisnika.TabIndex = 5;
            // 
            // txt_prezimeKorisnika
            // 
            this.txt_prezimeKorisnika.Location = new System.Drawing.Point(100, 47);
            this.txt_prezimeKorisnika.Name = "txt_prezimeKorisnika";
            this.txt_prezimeKorisnika.Size = new System.Drawing.Size(128, 20);
            this.txt_prezimeKorisnika.TabIndex = 6;
            // 
            // txt_korisnickoIme
            // 
            this.txt_korisnickoIme.Location = new System.Drawing.Point(100, 82);
            this.txt_korisnickoIme.Name = "txt_korisnickoIme";
            this.txt_korisnickoIme.Size = new System.Drawing.Size(128, 20);
            this.txt_korisnickoIme.TabIndex = 7;
            // 
            // txt_sifra
            // 
            this.txt_sifra.Location = new System.Drawing.Point(100, 108);
            this.txt_sifra.Name = "txt_sifra";
            this.txt_sifra.Size = new System.Drawing.Size(128, 20);
            this.txt_sifra.TabIndex = 8;
            // 
            // txt_sifraPonovo
            // 
            this.txt_sifraPonovo.Location = new System.Drawing.Point(100, 131);
            this.txt_sifraPonovo.Name = "txt_sifraPonovo";
            this.txt_sifraPonovo.Size = new System.Drawing.Size(128, 20);
            this.txt_sifraPonovo.TabIndex = 9;
            // 
            // btn_registracija
            // 
            this.btn_registracija.Location = new System.Drawing.Point(130, 168);
            this.btn_registracija.Name = "btn_registracija";
            this.btn_registracija.Size = new System.Drawing.Size(75, 23);
            this.btn_registracija.TabIndex = 10;
            this.btn_registracija.Text = "Registracija";
            this.btn_registracija.UseVisualStyleBackColor = true;
            // 
            // Registracija
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.btn_registracija);
            this.Controls.Add(this.txt_sifraPonovo);
            this.Controls.Add(this.txt_sifra);
            this.Controls.Add(this.txt_korisnickoIme);
            this.Controls.Add(this.txt_prezimeKorisnika);
            this.Controls.Add(this.txt_imeKorisnika);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Registracija";
            this.Text = "Registracija";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_imeKorisnika;
        private System.Windows.Forms.TextBox txt_prezimeKorisnika;
        private System.Windows.Forms.TextBox txt_korisnickoIme;
        private System.Windows.Forms.TextBox txt_sifra;
        private System.Windows.Forms.TextBox txt_sifraPonovo;
        private System.Windows.Forms.Button btn_registracija;
    }
}