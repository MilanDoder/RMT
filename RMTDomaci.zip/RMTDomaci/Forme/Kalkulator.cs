﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forme
{
    public partial class Kalkulator : Form
    {
        private static string izraz = "";
        public Kalkulator()
        {
            InitializeComponent();
        }

        private void btn_jedan_Click(object sender, EventArgs e)
        {
            izraz += "1";
            rtxt_rezultat.Text =  izraz;
        }

        private void btn_dva_Click(object sender, EventArgs e)
        {
            izraz += "2";
            rtxt_rezultat.Text = izraz;
        }

        private void btn_tri_Click(object sender, EventArgs e)
        {
            izraz += "3";
            rtxt_rezultat.Text = izraz;
        }

        private void btn_cetiri_Click(object sender, EventArgs e)
        {
            izraz += "4";
            rtxt_rezultat.Text = izraz;
        }

        private void btn_pet_Click(object sender, EventArgs e)
        {
            izraz += "5";
            rtxt_rezultat.Text = izraz;
        }

        private void btn_sest_Click(object sender, EventArgs e)
        {
            izraz += "6";
            rtxt_rezultat.Text = izraz;
        }

        private void btn_sedam_Click(object sender, EventArgs e)
        {
            izraz += "7";
            rtxt_rezultat.Text = izraz;
        }

        private void btn_osam_Click(object sender, EventArgs e)
        {
            izraz += "8";
            rtxt_rezultat.Text = izraz;
        }

        private void btn_devet_Click(object sender, EventArgs e)
        {
            izraz += "9";
            rtxt_rezultat.Text = izraz;
        }

        private void btn_nula_Click(object sender, EventArgs e)
        {
            izraz += "0";
            rtxt_rezultat.Text = izraz;
        }
        /// <summary>
        /// Operacije
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_podeljeno_Click(object sender, EventArgs e)
        {
            izraz += "/";
            rtxt_rezultat.Text = izraz;
            IskljuciOperacije();
        }

        private void btn_puta_Click(object sender, EventArgs e)
        {
            izraz += "*";
            rtxt_rezultat.Text = izraz;
            IskljuciOperacije();
        }

        private void btn_razlika_Click(object sender, EventArgs e)
        {
            izraz += "-";
            rtxt_rezultat.Text = izraz;
            IskljuciOperacije();
        }

        private void btn_zbir_Click(object sender, EventArgs e)
        {
            izraz += "+";
            rtxt_rezultat.Text = izraz;
            IskljuciOperacije();
        }

        private void btn_jednako_Click(object sender, EventArgs e)
        {
            int rezultat = izracunajIzraz(izraz);
            rtxt_rezultat.Text = rezultat.ToString();
            UkljuciOperacije();
            ///pre ovoga sacuvati izraz i rezultat
            izraz = "";
            //rtxt_rezultat.Text = "";
        }


        private int izracunajIzraz(string izraz)
        {
            int sum = int.MinValue;
            if (izraz.Contains("+"))
            {
                string prvibroj = izraz.Substring(0, izraz.IndexOf("+"));
                string drugibroj = izraz.Substring(izraz.IndexOf("+") + 1);
                sum = Convert.ToInt32(prvibroj) + Convert.ToInt32(drugibroj);
            }
            else if (izraz.Contains("-"))
            {

                string prvibroj = izraz.Substring(0, izraz.IndexOf("-"));
                string drugibroj = izraz.Substring(izraz.IndexOf("-") + 1);

                sum = Convert.ToInt32(prvibroj) - Convert.ToInt32(drugibroj);

            }
            else if (izraz.Contains("*"))
            {

                string prvibroj = izraz.Substring(0, izraz.IndexOf("*"));
                string drugibroj = izraz.Substring(izraz.IndexOf("*") + 1);
                sum = Convert.ToInt32(prvibroj) * Convert.ToInt32(drugibroj);
            }
            else if (izraz.Contains("/"))
            {
                string prvibroj = izraz.Substring(0, izraz.IndexOf("/"));
                string drugibroj = izraz.Substring(izraz.IndexOf("/") + 1);
                sum = Convert.ToInt32(prvibroj) / Convert.ToInt32(drugibroj);
            }



            return sum;
        }


        private void IskljuciOperacije() {
            btn_puta.Enabled = false;
            btn_zbir.Enabled = false;
            btn_razlika.Enabled = false;
            btn_podeljeno.Enabled = false;
        }
        private void UkljuciOperacije() {
            btn_puta.Enabled = true;
            btn_zbir.Enabled = true;
            btn_razlika.Enabled = true;
            btn_podeljeno.Enabled = true;
        }

    }
}
