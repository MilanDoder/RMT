﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Baza
{
    public class BazaPodataka
    {
        private static BazaPodataka _instanca;
        private SqlConnection konekcija;
        private string v;

        public static BazaPodataka Instanca {
            get {
                if (_instanca == null) {
                    _instanca = new BazaPodataka();
                }
                return _instanca;
            }
        }

        private BazaPodataka() {
            konekcija = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=RMTDomaci;Integrated Security=True;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        }

        
    }
}
